<?php
 
     $resultCode    = $_REQUEST["resultCode"];
     $errorCode     = $_REQUEST["errorCode"];
     $resultMsg     = $_REQUEST["resultMsg"];
     $orderID       = $_REQUEST["orderID"];
     $mid           = $_REQUEST["mid"];
     $sid           = $_REQUEST["sid"];
	 $paymethod     = $_REQUEST["paymethod"];
 
  
   if ($_REQUEST["resultCode"] === "OK") {
 
        $data = array(
         'Mid' => $mid,
         'Sid' => $sid
        );
 
        // curl 통신 시작 
		
		$url = "https://cbt.inicis.com/cbtapprove";
        
        $ch = curl_init();                                                //curl 초기화
        curl_setopt($ch, CURLOPT_URL, $url );                             //URL 지정하기
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                   //요청 결과를 문자열로 반환 
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);                     //connection timeout 10초 
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);                      //원격 서버의 인증서가 유효한지 검사 안함
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));    //POST 로 $data 를 보냄
        curl_setopt($ch, CURLOPT_POST, 1);                                //true시 post 전송 
		
		$response = curl_exec($ch);
		$info = curl_getinfo($ch);
        curl_close($ch);
		
        parse_str($response, $out);

//print_r($out);
}
?>
<!DOCTYPE html>
<html lang="ko">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport"
            content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>KG이니시스 결제샘플</title>
        <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
    </head>

    <body class="wrap">

        <!-- 본문 -->
        <main class="col-8 cont" id="bill-01">
		    <!-- 페이지타이틀 -->
            <section class="mb-5">
                <div class="tit">
                    <h2>일본결제</h2>
                    <p>KG이니시스 결제창을 호출하여 CBT 결제를 제공하는 서비스</p>
                </div>
            </section>
            <!-- //페이지타이틀 -->

            <!-- 카드CONTENTS -->
            <section class="menu_cont mb-5">
                <div class="card">
                    <div class="card_tit">
                        <h3>CBT결제</h3>
                    </div>

                    <form name="" id="result" method="post" class="mt-5">
                    <div class="row g-3 justify-content-between" style="--bs-gutter-x:0rem;">
 
                        <label class="col-10 col-sm-2 gap-2 input param" style="border:none;">resultCode</label>
                        <label class="col-10 col-sm-9 input">
                            <?php echo @(in_array($out["resultCode"] , $out) ? $out["resultCode"] : $_REQUEST["resultCode"] ) ?>
                        </label>
						
						<label class="col-10 col-sm-2 input param" style="border:none;">errorCode</label>
                        <label class="col-10 col-sm-9 input">
                            <?php echo @(in_array($out["errorCode"] , $out) ? $out["errorCode"] : $_REQUEST["errorCode"] ) ?>
                        </label>
						
						<label class="col-10 col-sm-2 input param" style="border:none;">resultMsg</label>
                        <label class="col-10 col-sm-9 input">
                            <?php echo @(in_array($out["resultMsg"] , $out) ? $out["resultMsg"] : $_REQUEST["resultMsg"] ) ?>
                        </label>
						
						<label class="col-10 col-sm-2 input param" style="border:none;">tid</label>
                        <label class="col-10 col-sm-9 input">
                            <?php echo @(in_array($out["tid"] , $out) ? $out["tid"] : "" ) ?>
                        </label>
						
						<label class="col-10 col-sm-2 input param" style="border:none;">applDate</label>
                        <label class="col-10 col-sm-9 input">
                            <?php echo @(in_array($out["applDate"] , $out) ? $out["applDate"] : "" ) ?>
                        </label>
						
						<label class="col-10 col-sm-2 input param" style="border:none;">applTime</label>
                        <label class="col-10 col-sm-9 input">
                            <?php echo @(in_array($out["applTime"] , $out) ? $out["applTime"] : "" ) ?>
                        </label>
						
						<label class="col-10 col-sm-2 input param" style="border:none;">paymethod</label>
                        <label class="col-10 col-sm-9 input">
                            <?php echo @(in_array($out["paymethod"] , $out) ? $out["paymethod"] : "" ) ?>
                        </label>
						
						<?php

 
                        if (isset($out["paymethod"]) && strcmp("VBank", $out["paymethod"]) == 0) { //신용카드
                            echo "
                            <label class='col-10 col-sm-2 input param' style='border:none;'>cardCode</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["cardCode"] , $out) ? $out["cardCode"] : "" ).
                            "</label>
                         
                            <label class='col-10 col-sm-2 input param' style='border:none;'>approve</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["approve"] , $out) ? $out["approve"] : "" ).
                            "</label>
							
							<label class='col-10 col-sm-2 input param' style='border:none;'>payType</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["payType"] , $out) ? $out["payType"] : "" ).
                            "</label>
                         
                            <label class='col-10 col-sm-2 input param' style='border:none;'>installMonth</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["installMonth"] , $out) ? $out["installMonth"] : "" ).
                            "</label>"
                         
                            ;
                        } else if (isset($out["paymethod"]) && strcmp("CVS", $out["paymethod"]) == 0) { //편의점
                            echo "
							
							<label class='col-10 col-sm-2 input param' style='border:none;'>convenience</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["convenience"] , $out) ? $out["convenience"] : "" ).
                            "</label>
							
							<label class='col-10 col-sm-2 input param' style='border:none;'>confNo</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["confNo"] , $out) ? $out["confNo"] : "" ).
                            "</label>
							
							<label class='col-10 col-sm-2 input param' style='border:none;'>receiptNo</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["receiptNo"] , $out) ? $out["receiptNo"] : "" ).
                            "</label>
							
                            <label class='col-10 col-sm-2 input param' style='border:none;'>paymentTerm</label>
                            <label class='col-10 col-sm-9 reinput'>".@(in_array($out["paymentTerm"] , $out) ? $out["paymentTerm"] : "" ).
                            "</label>"
                            ;
                        }
						
						?>
 
                    </div>
                </form>
				
				<button onclick="location.href='request.php'" class="btn_solid_pri col-6 mx-auto btn_lg" style="margin-top:50px">돌아가기</button>
					
                </div>
				
				
            </section>
			
        </main>
		
    </body>
</html>