<?php
	/*
	 * Test MID 및 TEST MID SEEDKEY, SEEDIV
	 * 실제 MID 연동 시 실제 MID 및 전달받은 SEEDKEY, SEEDIV Setting 해야함
	*/
	$MID = "INICAStest";
	$SEEDKEY = "EcSXmC9Uz3Q9/a2EdC9Xtg==";
	$SEEDIV = "CASINICASTEST000";
?>