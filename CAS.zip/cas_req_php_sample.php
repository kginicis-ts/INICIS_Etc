<?php
	include "casConfig.php";
	//require_once ('./libs/KISA_SEED_CBC.php');
	require_once ('./libs/INILib.php');

?>

<?php
	/*
	 * ##### 요청 파라미터 셋팅 #####
	 * ## Test MID -> 'INICAStest' MID는 테스트 MID 이며 인증확인 시 샘플 성공 응답이 응답값으로 나갑니다. ##
	 * ## 실제 가맹점 MID로 테스트 시 인증 여부에 따라 과금 발생될 수 있습니다. ##
	 */
	$mid		= "INICAStest";				// [필수] 가맹점 MID
	$Siteurl	= "www.inicis.com";		// [필수] 가맹점 도메인 -> (URL Encoding 대상필드)
	$Tradeid	= "test12345";			// [필수] 가맹점 거래번호
	$DI_CODE	= "Test001DI";			// [옵션] 웹 사이트 코드
	$MSTR		= "a=1|b=2";			// [옵션] 가맹점 콜백변수 -> (URL Encoding 대상필드)
	$Closeurl	= "http://172.30.23.144:8090/CAS/close.php";	// [필수] 취소, 닫기버튼 클릭 시 호출되는 가맹점 페이지 URL -> (URL Encoding 대상필드)
	$Okurl		= "http://172.30.23.144:8090/CAS/cas_res_php_sample.php";	// [필수] 인증응답 결과 전달용 가맹점 완료 페이지 URL -> (URL Encoding 대상필드)

	$Siteurl	= urlencode($Siteurl);
	$MSTR		= urlencode($MSTR);
	$Closeurl	= urlencode($Closeurl);
	$Okurl		= urlencode($Okurl);
	$encryptYN		= "Y";

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="Content-Script-Type" content="text/javascript" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />

	<title>카드본인확인 서비스 요청 Sample</title>

	<style>
		html, body, input, textarea{font-family:FontAwesome; font-size:13px; line-height:18px; color: #000;}
		h1{font-size:28px;text-align: center;}
		table{width: 380px;margin:0 auto;text-align: center;}

		.btnBox{margin-top: 30px;text-align: left;}
		.Btn{display:inline-block;*display:inline;zoom:1;font-size: 17px;color: #fff;font-weight:bold;text-align: center;vertical-align: middle;background: #333;height: 48px;line-height: 44px;min-width:380px;}
		input {padding:10px;width:500px;margin-bottom:10px;}
		h4 {width:150px;}
	</style>
</head>

    <script> 
	    function openWindow() { 
	    	myform = document.reqfrm; 
	    	myform.action = "https://stgcas.inicis.com/casapp/ui/cardauthreq";
	    	myform.target = "_self";
	    	myform.submit(); 
	    }
    </script>
		
<!--script language="javascript">

	function openWindow(frm, url)
	{
		var IFWin;
		var OpenOption = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=450,height=750,top=100,left=100,';

		IFWin = window.open('', 'IfWindow', OpenOption);

		document.reqfrm.action = "https://stgcas.inicis.com/casapp/ui/cardauthreq";
		document.reqfrm.target = "IfWindow";
		document.reqfrm.submit();
	}

</script-->
<body>
	<h1 style="margin:50px 0px 50px 0px">카드 본인확인 서비스 Sample</h1>

	<form id="reqfrm" name="reqfrm" method="POST" >
	    <table>
		    <tr>
			    <td><h4>mid</h4></td>
			    <td><input type="text" id="mid" name="mid" value="<?php echo $mid ?>"/></td>
			</tr>
			<tr>
			    <td><h4>Siteurl</h4></td>
			    <td><input type="text" id="Siteurl" name="Siteurl" value="<?php echo $Siteurl ?>"/></td>
			</tr>
			<tr>
			    <td><h4>Tradeid</h4></td>
			    <td><input type="text" id="Tradeid" name="Tradeid" value="<?php echo $Tradeid ?>"/></td>
			</tr>
			<tr>
			    <td><h4>DI_CODE</h4></td>
			    <td><input type="text" id="DI_CODE" name="DI_CODE" value="<?php echo $DI_CODE ?>"/></td>
			</tr>
			<tr>
			    <td><h4>MSTR</h4></td>
			    <td><input type="text" id="MSTR" name="MSTR" value="<?php echo $MSTR ?>"/></td>
			</tr>
			<tr>
			    <td><h4>Closeurl</h4></td>
			    <td><input type="text" id="Closeurl" name="Closeurl" value="<?php echo $Closeurl ?>"/></td>
			</tr>
			<tr>
			    <td><h4>Okurl</h4></td>
			    <td><input type="text" id="Okurl" name="Okurl" value="<?php echo $Okurl ?>"/></td>
			</tr>
			<tr>
			    <td><h4>encryptYN</h4></td>
			    <td><input type="text" id="encryptYN" name="encryptYN" value="<?php echo $encryptYN ?>"/></td>
			</tr>
			
		</table>
	</form>

	<table>
		<tr>
			<td>
				<div>
					<button class="Btn" onclick="openWindow();">인증요청</button>
				</div>
			</td>
		</tr>
	</table>
</body>
</html>