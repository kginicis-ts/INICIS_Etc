
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.JSONArray;

public class billing {

	public static void main(String[] args) throws Exception {

		SHA512 sha512 = new SHA512();
		AES128 aes128 = new AES128();
		Date date_now = new Date(System.currentTimeMillis());
		SimpleDateFormat fourteen_format = new SimpleDateFormat("yyyyMMddHHmmss");

		//step1. 요청을 위한 파라미터 설정						
		String key = "A6bR2h1RItVaOunD"; 							
		String iv = "inJ8EL6x06VS3f==";			
		String main_mid = "sepbiltst1";	
		String timestamp = fourteen_format.format(date_now);		
		String clientIp = "127.0.0.1";
		String url = "www.test.com";
		String buyerName = "홍길동";
		String buyerEmail = "test@test.com";
		String buyerTel = "01011112222";
		String billKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
	
		
		//data 1 생성
		Map<String, Object> data1 = new HashMap<String, Object>();
		data1.put("mid", "sepbiltst1");
	 	data1.put("goodsName", "test1");
	 	data1.put("moid", "테스트상품1");
	 	data1.put("price", "1001");
	 	data1.put("cardQuota", "00");
	 	data1.put("authentification", "00");
	 	data1.put("quotaInterest", "");
	 	data1.put("tax", "");
	 	data1.put("taxFree", "");

	 	
	 	//data 2 생성
	 	Map<String, Object> data2 = new HashMap<String, Object>();
	 	data2.put("mid", "sepbillsub");
	 	data2.put("goodsName", "test2");
	 	data2.put("moid", "테스트상품2");
	 	data2.put("price", "1002");
	 	data2.put("cardQuota", "00");
	 	data2.put("authentification", "00");
	 	data2.put("quotaInterest", "");
	 	data2.put("tax", "");
	 	data2.put("taxFree", "");
	 	
	 	JSONObject jsonData1 = new JSONObject(data1);	
	 	JSONObject jsonData2 = new JSONObject(data2);
	 	
	    JSONArray dataArray = new JSONArray();
	    dataArray.add(jsonData1);
	    dataArray.add(jsonData2);
	    
	 // AES Encryption 
	 	String encsubData = aes128.encAES(dataArray.toString(), key, iv);

		// Hash Encryption 
		String plainTxt = key + timestamp + clientIp + main_mid + encsubData ;
		plainTxt = plainTxt.replaceAll("\\\\", "");
		String hashData = sha512.hash(plainTxt);
		
		
		// reqeust URL
		String apiUrl = "https://iniapi.inicis.com/api/v1/dividepayCardBill";
		
		 JSONObject respJson = new JSONObject();
		    respJson.put("mid", main_mid);
		    respJson.put("timestamp", timestamp);
		    respJson.put("clientIp",clientIp);
		    respJson.put("url",url);
		    respJson.put("buyerName", buyerName);
		    respJson.put("buyerEmail",buyerEmail);
		    respJson.put("buyerTel",buyerTel);
		    respJson.put("billKey",billKey);
		    respJson.put("hashData",hashData);
		    respJson.put("subData",encsubData);
		    		   
		
		//step2.  요청
		try {
			URL reqUrl = new URL(apiUrl);
			HttpURLConnection conn = (HttpURLConnection) reqUrl.openConnection();
			
			if (conn != null) {
				conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
				conn.setRequestMethod("POST");
				conn.setDefaultUseCaches(false);
				conn.setDoOutput(true);
				
				if (conn.getDoOutput()) {
					conn.getOutputStream().write(respJson.toString().getBytes("UTF-8"));
					conn.getOutputStream().flush();
					conn.getOutputStream().close();
				}

				conn.connect();
				
					BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
					
					//step3. 요청 결과
					System.out.println(br.readLine()); 
					br.close();
				}

		}catch(Exception e ) {
			e.printStackTrace();
		} 
	}
}

