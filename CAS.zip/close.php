<html>
    <script>
	    //팝업방식 사용 시
		opener.location.href = "https://naver.com";
		close();
		
		//페이지 전환방식 사용 시
		//location.href = "https://naver.com";
	</script>
</html>