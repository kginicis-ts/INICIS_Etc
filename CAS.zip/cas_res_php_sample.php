<?php
	include "casConfig.php";
	require_once ('./libs/KISA_SEED_CBC.php');
	require_once ('./libs/INILib.php');
?>

<?php
	/*
	 * 실제 가맹점 MID로 테스트 시 인증 여부에 따라 과금 발생될 수 있습니다.
	 */
	$Resultcd		= $_POST["Resultcd"];	// 결과코드
	$Resultmsg		= $_POST["Resultmsg"];	// 결과 메시지 ->URLEncoding
	$Transid		= $_POST["Transid"];	// 트랜잭션 ID
	$Tradeid		= $_POST["Tradeid"];	// 가맹점 거래번호
	$MSTR			= $_POST["MSTR"];		// 가맹점 콜백변수 -> URLEncoding
	$Signdate		= $_POST["Signdate"];	// 인증일자
	$Name			= $_POST["Name"];		// 이름 -> [SEED 암호화]		ex) 홍길동
	$Socialno		= $_POST["Socialno"];	// 생년월일 -> [SEED 암호화]	ex) 20190101
	$Sex			= $_POST["Sex"];		// 성별 -> [SEED 암호화]		ex) M
	$Foreigner		= $_POST["Foreigner"];	// 외국인 여부 -> [SEED 암호화]	ex) L
	$Ci				= $_POST["Ci"];			// Ci -> 기 암호화				comment : 기 암호화 된 데이터로 그대로 사용.
	$Di				= $_POST["Di"];			// Di -> 기 암호화				comment : 기 암호화 된 데이터로 그대로 사용.
	$DI_CODE		= $_POST["DI_CODE"];	// 웹 사이트 코드
	$Mac			= $_POST["Mac"];		// Hash Value -> [sah256]		ex)mid값+signdate값+Ci값+Tradeid값+Transid값
	if(strcmp($Resultmsg, "") != 0){
		$Resultmsg = urldecode($Resultmsg);
	}

	if(strcmp($MSTR, "") != 0){
		$MSTR = urldecode($MSTR);
	}

	$oriMac = "";

	if(strcmp($Resultcd, "0000") == 0){ // 결과코드 (0000)인 경우 - 성공

		// signature 생성(순서주의:연동규약서 참고)
		$oriMac = "" . $MID;
        $oriMac = $oriMac . "" . $Signdate;
        $oriMac = $oriMac . "" . $Ci;
        $oriMac = $oriMac . "" . $Tradeid;
        $oriMac = $oriMac . "" . $Transid;

		$oriMac = hash("sha256", $oriMac); // oriMac 데이터 sha-256 적용

		/* 데이터 위변조 체크 가능 */
		if(strcmp($oriMac, $Mac) != 0){
			/*
			 * 데이터 위변조 에러 발생
			 * 데이터 위변조 에러 가맹점 DB 처리
			 * ......
             * ........
             * ..........
			 */
		}else{
			/*
			 * 인증 성공
			 */

			// SEED 복호화 처리
            $Name = decrypt_SEED($Name, $SEEDKEY, $SEEDIV);
            $Socialno = decrypt_SEED($Socialno, $SEEDKEY, $SEEDIV);
			$Sex = decrypt_SEED($Sex, $SEEDKEY, $SEEDIV);
			$Foreigner = decrypt_SEED($Foreigner, $SEEDKEY, $SEEDIV);

			$Name = iconv("EUC-KR", "UTF-8", $Name);

			/*
			 *	인증성공 가맹점 DB처리
			 * ......
             * ........
             * ..........
			 */
		}

	}else{ // 결과코드 (0000) 아닌 경우 - 인증실패
		/*
		 * 인증 실패 시 가맹점 DB처리
		 * ......
         * ........
         * ..........
		 */
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Script-Type" content="text/javascript">
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge, chrome=1"/>
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">

	<title>카드본인확인 서비스 응답 Sample</title>

	<style>
		html, body, input, textarea{font-family:FontAwesome; font-size:13px; line-height:18px; color: #000;}
		h1{font-size:28px;color:#f00;text-align: center;}
		h3{font-size:45px;color:#535EC6;text-align: center;}
		table.orange{width: 380px;margin:0 auto;background:blue;text-align: right;}
		table{width: 380px;margin:0 auto;text-align: center;}

		.btnBox{margin-top: 30px;text-align: left;}
		.Btn{display:inline-block;*display:inline;zoom:1;font-size: 17px;color: #fff;font-weight:bold;text-align: center;vertical-align: middle;background: #333;height: 48px;line-height: 44px;min-width:380px;}
	</style>
</head>
<body>
	<h1>카드 본인확인 서비스 Sample</h1>

	<table class="orange">
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Resultcd
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Resultcd ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Resultmsg
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Resultmsg ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Transid
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Transid ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Tradeid
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Tradeid ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				MSTR
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $MSTR ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Signdate
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Signdate ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Name
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Name ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Socialno
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Socialno ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Sex
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Sex ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Foreigner
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Foreigner ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Ci
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Ci ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Di
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Di ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				DI_CODE
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $DI_CODE ?>
			</td>
		</tr>
		<tr>
			<td width="100" height="30" bgcolor="#FFFFE0" align="center">
				Mac
			</td>
			<td width="280" height="30" bgcolor="#FFFFE0">
				<?php echo $Mac ?>
			</td>
		</tr>
	</table>

	<br />

	<table>
		<tr>
			<td>
				<div class="btnBox">
					<a href="javascript:close();" class="Btn">인증확인</a>
				</div>
			</td>
		</tr>
	</table>
</body>
</html>